//let x:number = parseFloat(prompt("Enter a number"));
//console.log(x+3);

let courses = ["Angular","React","Express"];

console.log(courses.toString());

let mybool = false;
let x:string = mybool.toString();
console.log(x);