var n = 10;
var i = 1;
while (i <= n) {
    console.log(i++);
}
