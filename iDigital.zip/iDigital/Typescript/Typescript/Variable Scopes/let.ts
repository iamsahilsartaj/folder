function myFun():void{


for(let i=0;i<10;i++){
    console.log(i);
}

var i = 10;

}