function myFun() {
    for (var i_1 = 0; i_1 < 10; i_1++) {
        console.log(i_1);
    }
    var i = 10;
}
