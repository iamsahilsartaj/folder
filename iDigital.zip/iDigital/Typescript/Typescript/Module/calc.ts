export default class Calculator{
add(x:number,y:number):number{
    return x+y;
}

sub(x:number,y:number):number{
    return x-y;
}
}

export  class Calculator1{
    add(x:number,y:number):number{
        return x+y;
    }
    
    sub(x:number,y:number):number{
        return x-y;
    }
    }
    
