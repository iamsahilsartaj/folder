var product1 = {
    id: 123,
    name: "IPhone",
    description: "Its awesome",
    price: 1000
};
var product2 = {
    id: 123,
    name: "IPhone",
    description: "Its awesome",
    price: 1000
};
