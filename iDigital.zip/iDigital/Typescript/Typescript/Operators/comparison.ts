var x:number = 40;
var y:number = 50;

console.log(x===30);
console.log(x!==30);
console.log(x<y);