public class MyFirstClass {
    public static void main(String[] args) {
        System.out.println("Hi");

        int a=10;
        int b=a+2;
        int z=a+b+1;
        System.out.println(z);
    }
}
